import 'package:flutter/material.dart';

const kcontentColor = Colors.grey;
const kprimaryColor = Colors.blue;
